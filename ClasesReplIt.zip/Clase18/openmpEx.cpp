
/*
#include <iostream>
//g++ -fopenmp openmpEx.cpp
//export OMP_NUM_THREADS=2


int main(void)
{
#pragma omp parallel  num_threads (4)
{
  std::cout << "Hello world\n"; 
}
  return 0;
}
*/