#include <iostream>
//g++ -fopenmp main.cpp
//export OMP_NUM_THREADS=2


int main(void)
{
#pragma omp parallel  num_threads (2)
{
  std::cout << "Hello world\n"; 
}
  return 0;




  ///////EWrfuygiugigiguftyfufigigiguiguig



  ////hfgugihigigighiuhihiuhuihiuhui



  ///jhgjhgjgjgjhgjgjgj
}